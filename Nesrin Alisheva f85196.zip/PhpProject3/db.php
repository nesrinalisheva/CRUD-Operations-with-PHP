<?php
$con=mysql_connect('localhost', 'root', '') or die('Error Connect to Database');
mysql_select_db('parfumes', $con) or die('Error Select Database');
?>
